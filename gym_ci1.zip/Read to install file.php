
1. install xampp softaware and run apache server and mysql server

2. fist install database in xampp software db name- must - 'gym' (database file in 'sql' folder)

3. copy zip file and extract to - c:xampp/htdocs/gym_ci

4. folder name must - 'gym_ci'

5. select chrome and new tab  and paste the url like - http://localhost/gym_ci/index

admin login:
Admin username : gym@gym.in
Admin password : gym

demo - user login:
username: user@gym.in
password : gym
