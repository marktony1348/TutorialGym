<script src="<?php echo base_url()?>assets/admin/plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap tether Core JavaScript -->
    <script src="<?php echo base_url()?>assets/admin/plugins/bower_components/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/js/app-style-switcher.js"></script>
    <script src="<?php echo base_url()?>assets/admin/plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js"></script>
    <!--Wave Effects -->
    <script src="<?php echo base_url()?>assets/admin/js/waves.js"></script>
    <!--Menu sidebar -->
    <script src="<?php echo base_url()?>assets/admin/js/sidebarmenu.js"></script>
    <!--Custom JavaScript -->
    <script src="<?php echo base_url()?>assets/admin/js/custom.js"></script>
    <!--This page JavaScript -->
    <!--chartis chart-->
    <script src="<?php echo base_url()?>assets/admin/plugins/bower_components/chartist/dist/chartist.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/plugins/bower_components/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
    <script src="<?php echo base_url()?>assets/admin/js/pages/dashboards/dashboard1.js"></script>
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>
    
    
 <script>
        $('document').ready(function(){
                    $(document).ready( function () {
                        $('#table_id').DataTable();
                    } );  
    });
    </script>
    <footer class="footer text-center"> 2022 © All rights reserved by YOU
                <!-- <a href="https://www.wrappixel.com/">wrappixel.com</a> -->
            </footer>
           