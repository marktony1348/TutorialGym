<!DOCTYPE html>
<html>
<head>
	<title>Msg Stored</title>
</head>
<body>
	<a href="<?php echo base_url()?>">Home</a>
	<h1>Your message stored. reply come from through Mail.</h1>

</body>
</html>